package com.lianlian.securepay.demo.llpaysdk_m_pay_demo.wxapi;

import android.app.Activity;
import android.os.Bundle;

import com.lianlian.securepay.demo.llpaysdk_m_pay_demo.R;


public class WXPayEntryActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

	}

}