package com.lianlian.securepay.demo.llpaysdk_m_pay_demo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.lianlian.base.OnResultListener;
import com.lianlian.mobilebank.MobileBankService;
import com.lianlian.securepay.token.SecurePayService;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText mGatewayUrlEt;
    private Button mPayBtn, mSignBtn, mBankpayBtn;
    private boolean mIsAutoGetSms = false;
    private TextView mResultTv;
    private int mType = 1;
    private RadioGroup mRgType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mGatewayUrlEt = findViewById(R.id.gateway_url_et);
        mPayBtn = findViewById(R.id.pay_btn);
        mBankpayBtn = findViewById(R.id.bankpay_btn);
        mSignBtn = findViewById(R.id.sign_btn);
        mResultTv = findViewById(R.id.result_tv);
        mRgType = findViewById(R.id.rg_type);

        mBankpayBtn.setOnClickListener(this);
        mPayBtn.setOnClickListener(this);
        mSignBtn.setOnClickListener(this);

        mRgType.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rb_normal) {
                    mType = 1;//正式
                } else if (checkedId == R.id.rb_test) {
                    mType = 0;//测试
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.pay_btn) {
            if (!TextUtils.isEmpty(mGatewayUrlEt.getText().toString())) {
                SecurePayService.securePay(this, mGatewayUrlEt.getText().toString(), mType, mResultListener, mIsAutoGetSms);
            } else {
                mResultTv.setText("请输入GatewayUrl");
            }
        } else if (v.getId() == R.id.sign_btn) {
            if (!TextUtils.isEmpty(mGatewayUrlEt.getText().toString())) {
                SecurePayService.secureSign(this, mGatewayUrlEt.getText().toString(), mType, mResultListener, mIsAutoGetSms);
            } else {
                mResultTv.setText("请输入GatewayUrl");
            }
        } else if (v.getId() == R.id.bankpay_btn) {
            if (!TextUtils.isEmpty(mGatewayUrlEt.getText().toString())) {
                MobileBankService.pay(this, mGatewayUrlEt.getText().toString(), mType, mResultListener);
            } else {
                mResultTv.setText("请输入GatewayUrl");
            }
        }

    }

    OnResultListener mResultListener = new OnResultListener() {
        @Override
        public void onResult(JSONObject result) {
            mResultTv.setText("返回内容：\n" + result.toString());
        }
    };

}
