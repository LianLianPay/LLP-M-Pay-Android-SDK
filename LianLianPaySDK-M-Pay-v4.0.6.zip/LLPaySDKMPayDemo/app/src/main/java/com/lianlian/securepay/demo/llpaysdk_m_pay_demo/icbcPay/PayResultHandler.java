package com.lianlian.securepay.demo.llpaysdk_m_pay_demo.icbcPay;


import android.app.Activity;
import android.os.Bundle;


public class PayResultHandler extends Activity {


	@Override
	protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);


    }

}
